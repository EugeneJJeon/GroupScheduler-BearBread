package bearbread.org.groupscheduler.eugene.database;

/**
 * Created by Eugene J. Jeon on 2015-04-08.
 */
public class Constants {
	// Log Class에 인자로 넘겨줄 TAG 정의
	public static final String LOG_TAG = "GroupScheduler";
}
