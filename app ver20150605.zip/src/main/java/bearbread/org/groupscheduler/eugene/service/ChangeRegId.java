package bearbread.org.groupscheduler.eugene.service;

/**
 * Created by Eugene J. Jeon on 2015-06-05.
 */
public class ChangeRegId {
    public static boolean CAHNGE_REG_ID = false;
}
